# Opscaler.ai Website

Production-ready single-page marketing site for Opscaler.ai.

---

## 📦 What's in this folder

| File | What it does |
|------|-------------|
| `index.html` | The entire website — all HTML, CSS, JS, and logo embedded in one file |
| `.nojekyll` | Tells GitHub Pages to serve the files as-is (skip Jekyll processing) |
| `README.md` | This file |

That's it. No build step, no dependencies, no backend.

---

## 🚀 Publishing to GitHub Pages — Step by Step

### Option A: Quick publish on a GitHub subdomain (10 minutes)

This gets you a live site at `https://<your-github-username>.github.io/opscaler/` with no domain needed.

1. **Sign in to [github.com](https://github.com)** (create a free account if you don't have one)

2. **Create a new repository**
   - Click the **+** in the top-right → **New repository**
   - Name it something like `opscaler` or `opscaler-site`
   - Set it to **Public** (required for free GitHub Pages)
   - Do **not** check "Add a README" (we already have one)
   - Click **Create repository**

3. **Upload your files**
   - On the new empty repo page, click **"uploading an existing file"**
   - Drag all three files into the upload area:
     - `index.html`
     - `.nojekyll`
     - `README.md`
   - Scroll down, click **Commit changes**

4. **Enable GitHub Pages**
   - Click the **Settings** tab at the top of your repo
   - In the left sidebar, click **Pages**
   - Under **Source**, select branch: **`main`** and folder: **`/ (root)`**
   - Click **Save**
   - Wait 1–2 minutes. Refresh the page.

5. **Visit your live site**
   - GitHub will show a green box at the top of the Pages settings: *"Your site is live at https://<username>.github.io/<repo-name>/"*
   - Click the link. You're live. 🎉

---

### Option B: Use your custom domain `opscaler.ai` (15 extra minutes)

After completing Option A, do the following to point your domain at the site:

1. **In your GitHub repo:**
   - Go to **Settings → Pages**
   - Under **Custom domain**, type: `opscaler.ai`
   - Click **Save**
   - GitHub will automatically create a file called `CNAME` in your repo

2. **At your domain registrar** (wherever you bought `opscaler.ai` — GoDaddy, Namecheap, Cloudflare, etc.):
   - Open your domain's **DNS settings**
   - **Remove** any existing `A` records pointing to parked pages
   - **Add four `A` records** for the root domain (`@` or blank host):
     ```
     A   @   185.199.108.153
     A   @   185.199.109.153
     A   @   185.199.110.153
     A   @   185.199.111.153
     ```
   - **Add a `CNAME` record** for the `www` subdomain:
     ```
     CNAME   www   <your-github-username>.github.io
     ```
   - Save DNS changes

3. **Wait for DNS to propagate** (usually 15 min – 2 hours, occasionally up to 24 hours)

4. **Back in GitHub Pages settings:**
   - After DNS propagates, you'll see a green checkmark next to your domain
   - Check the **"Enforce HTTPS"** box (GitHub will auto-provision a free SSL cert from Let's Encrypt)

5. **Visit `https://opscaler.ai`** — you're live on your custom domain. 🎉

---

## 📧 How the Contact Form Works

The contact form uses a simple `mailto:` approach:

1. Visitor fills out the form
2. Their default email client (Gmail, Outlook, Apple Mail) opens with a pre-filled email addressed to `hello@opscaler.ai`
3. They click **Send**
4. You receive the email

**Why this approach?**
- ✅ Works immediately, no backend
- ✅ No API keys or external services
- ✅ No monthly fees
- ✅ Fully private — submissions never touch a third party
- ⚠️ Requires visitor to have a mail client configured and to click Send

**Want direct-send later?** See the **"Upgrading the Form"** section below.

---

## ✏️ Editing the Site

To make changes, edit `index.html` directly (any text editor works — VS Code, Notepad, Sublime, etc.). Then:

1. Save the file
2. Go to your repo on GitHub
3. Click on `index.html`
4. Click the pencil icon to edit
5. Paste the new content
6. Scroll down, click **Commit changes**
7. Your site updates automatically in about 30 seconds

**Or** — if you're comfortable with Git — `git clone` the repo, edit locally, and `git push`.

---

## 🔧 Upgrading the Form (when you're ready)

When you start getting traffic and want form submissions delivered directly without relying on the visitor's mail client:

### Easiest: **Web3Forms** (free, unlimited)
1. Go to [web3forms.com](https://web3forms.com) and grab a free access key
2. In `index.html`, find the `submitForm()` JavaScript function
3. Replace it with a `fetch()` POST to `https://api.web3forms.com/submit` — their docs show the exact pattern
4. Submissions arrive in your inbox automatically

### Also solid: **Formspree**
1. Sign up at [formspree.io](https://formspree.io) (free tier: 50 submissions/month)
2. Create a form, copy the endpoint
3. Swap the mailto logic for a `fetch()` to that endpoint

### If you switch hosting to Netlify: **Netlify Forms**
Free, built-in, just add `data-netlify="true"` to the form tag. But requires moving off GitHub Pages.

---

## 🎨 Customization Notes

**Case study numbers**
Currently representative. Swap in real data as you accumulate client outcomes.

**Testimonials**
Currently anonymized by industry. Ask satisfied clients for permission to use their name and business — real named testimonials convert far better.

**FAQ pricing answer**
The "mid-four-figure to low-five-figure" wording can be tuned to match your actual pricing as it solidifies.

**Colors, fonts, spacing**
All controlled by CSS variables at the top of `index.html` (look for `:root {`). Change `--accent`, `--paper`, `--ink` etc. to re-theme in seconds.

---

## 🐛 Troubleshooting

**"My site isn't showing up"**
- Wait 2–3 minutes after enabling Pages — initial builds take a moment
- Check **Settings → Pages** — there should be a green "Your site is live at..." banner
- Make sure the repo is **Public**, not Private (unless you have a paid GitHub plan)

**"My custom domain shows 'Not Secure' in the browser"**
- DNS may still be propagating. Wait up to 24 hours.
- Once DNS resolves, go to Pages settings and enable "Enforce HTTPS"

**"The form doesn't do anything when I click Send My Request"**
- The visitor needs a default email client configured (Mail on Mac, Outlook on Windows, Gmail on mobile, etc.)
- On a computer with no mail client, nothing will open — this is expected behavior. Upgrade to Web3Forms/Formspree (see above) to fix.

**"I made an edit and nothing changed on the live site"**
- GitHub Pages rebuilds take 30–90 seconds
- Hard-refresh the page: `Ctrl+Shift+R` (Windows) or `Cmd+Shift+R` (Mac)

---

## 📄 License

© 2025 Opscaler.ai. All rights reserved.
